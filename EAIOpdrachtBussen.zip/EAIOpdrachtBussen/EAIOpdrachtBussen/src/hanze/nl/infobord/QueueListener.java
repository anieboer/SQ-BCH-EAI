package hanze.nl.infobord;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

public class QueueListener implements MessageListener {
	//TODO 	implementeer de messagelistener die het bericht ophaald en
//			doorstuurd naar verwerkBericht van het infoBord.
//			Ook moet setRegels aangeroepen worden.
	}

