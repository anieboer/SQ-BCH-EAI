package hanze.nl.bussimulator;

public enum Bedrijven {
	QBUZZ, ARRIVA, FLIXBUS
}
